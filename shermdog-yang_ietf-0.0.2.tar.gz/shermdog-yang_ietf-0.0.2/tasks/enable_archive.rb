#!/opt/puppetlabs/puppet/bin/ruby

require 'json'
require 'net/netconf'
require 'puppet'
require 'puppet/util/network_device/config'
#require 'pry'

# Constants

device_conf = '/etc/puppetlabs/puppet/device.conf'

# RPC for enable archive
def archive_rpc(path)
  <<~HEREDOC
    <rpc xmlns="urn:ietf:params:xml:ns:netconf:base:1.0" message-id="3">
      <edit-config>
        <target><running/></target>
        <config xmlns:xc="urn:ietf:params:xml:ns:netconf:base:1.0">
          <native xmlns="http://cisco.com/ns/yang/Cisco-IOS-XE-native">
            <archive>
              <path>#{path}</path>
            </archive>
          </native>
        </interfaces>
      </config>
    </edit-config>
    </rpc>
  HEREDOC
end

# Input

args = JSON.parse(STDIN.read)

#noop = args['_noop'] ? '--noop' : ''
target = args['target']
path = args['path'] ? args['path'] : 'bootflash:archive'


# Pass config to Puppet - this would normally be available already on an agent run
Puppet[:deviceconfig] = "#{device_conf}"

# Get devices from config
devices = Puppet::Util::NetworkDevice::Config.devices.dup

# Remove all but taget device
devices.select! { |key, value| key == target }

# Fail if target is not configured
if devices.empty?
    # I think this will translate the error message
    error = Puppet.err _("Target device / certificate '%{target}' not found in %{config}") % { target: target, config: Puppet[:deviceconfig] }
    puts({ status: 'failure', error: error.message }.to_json)
    exit(1)
end

# Get the connection information from the config
device_url = URI.parse(devices[target].url)

# Default NETCONF port is 830
if device_url.port.nil?
  device_url.port = '830'
end

# Build connection string
login = { target: device_url.host, username: device_url.user, password: device_url.password, port: device_url.port, debug: 'true' }

# Create new Netconf device
dev = Netconf::SSH.new(login)

# Connect to device
dev.open

# Execute RPC
begin
  res = dev.rpc_exec(Nokogiri::XML(archive_rpc(path)).root)
rescue Netconf::RpcError => e
  error = Puppet.err _("Unable to enable archive on '%{target}': %{error}") % { target: target, error: e.rsp.xpath('//rpc-error/error-message').text }
  puts({ status: 'failure', error: error.message }.to_json)
  exit(1)
ensure
  # Close connection to device
  dev.close
end

puts({ status: 'success' }.to_json)
exit 0
