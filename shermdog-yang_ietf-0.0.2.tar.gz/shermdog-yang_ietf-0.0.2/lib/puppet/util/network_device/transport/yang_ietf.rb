require 'puppet/util/network_device'
require 'puppet/util/network_device/transport'
require 'puppet/util/network_device/transport/base'

class Puppet::Util::NetworkDevice::Transport::Yang_ietf < Puppet::Util::NetworkDevice::Transport::Base
  attr_reader :connection

  def initialize(url, _options = {})
    require 'uri'
    require 'net/netconf'
    @url = URI.parse(url)
    if @url.port.nil?
      @url.port = 830
    end
    Puppet.debug "Trying to connect to netconf #{@url.host} as #{@url.user} port #{@url.port}"
    login = { target: @url.host, username: @url.user, password: @url.password, port: @url.port, debug: 'true' }
    dev = Netconf::SSH.new(login)
    @connection = dev.open.rpc
  end
end
