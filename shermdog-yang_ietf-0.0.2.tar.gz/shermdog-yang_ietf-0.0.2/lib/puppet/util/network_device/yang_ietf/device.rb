require 'puppet/util/network_device'
require_relative('../yang_ietf/facts')
require_relative('../transport/yang_ietf')

class Puppet::Util::NetworkDevice::Yang_ietf::Device
  attr_reader :connection
  attr_accessor :url, :transport

  def initialize(url, options = {})
    @autoloader = Puppet::Util::Autoload.new(
      self,
      'puppet/util/network_device/transport'
    )
    if @autoloader.load('yang_ietf')
      @transport = Puppet::Util::NetworkDevice::Transport::Yang_ietf.new(url, options[:debug])
    end
  end

  def facts
    @facts ||= Puppet::Util::NetworkDevice::Yang_ietf::Facts.new(@transport)

    @facts.retrieve
  end
end
