require_relative('../util/network_device/yang_ietf')
require_relative('../util/network_device/transport/yang_ietf')

# This is the base class on which other providers are based.
class Puppet::Provider::Yang_ietf < Puppet::Provider # rubocop:disable all
  def initialize(value = {})
    super(value)
    @original_values = if value.is_a? Hash
                         value.clone
                       else
                         {}
                       end
    @create_elements = false
  end

  def self.prefetch(resources)
    nodes = instances
    resources.keys.each do |name|
      if provider = nodes.find { |node| node.name == name } # rubocop:disable all
        resources[name].provider = provider
      end
    end
  end

  def exists?
    @property_hash[:ensure] == :present
  end

  def self.device(url)
    Puppet::Util::NetworkDevice::Yang_ietf::Device.new(url)
  end

  def self.transport
    if Puppet::Util::NetworkDevice.current
      # we are in `puppet device`
      Puppet::Util::NetworkDevice.current.transport
    else
      # we are in `puppet resource`
      Puppet::Util::NetworkDevice::Transport::Yang_ietf.new(Facter.value(:url))
    end
  end

  def self.connection
    transport.connection
  end

  def self.netconf_get_config(filter, _args = nil)
    filter = Nokogiri::XML(filter)
    xml = connection.get_config(filter: filter)
    xml
  end

  def self.netconf_edit_config(config)
    config = case config.class.to_s
             when /^Nokogiri/
               config
             else
               Nokogiri::XML(config)
             end
    connection.edit_config(config: config)
  end

  def self.netconf_commit_config()
    connection.commit
  end

  def self.netconf_close(connection)
    puts "***Closing Connection***"
    connection.close_session
  end

  def self.xml_to_pcore(p_type, xml)
    i12n_hash = {}
    p_type.attributes(true).each_pair do |name, attr|
      next if attr.kind == 'constant'

      # Look for XML node mapping
      if p_type.attributes['xml_mapping']
        if p_type.attributes['xml_mapping'].value[name]
          node_set = xml.xpath(p_type.attributes['xml_mapping'].value[name])
        else
          node_set = xml.xpath(name.gsub(/_/, '-'))
        end
      else
        node_set = xml.xpath(name.gsub(/_/, '-'))
      end
      next if node_set.empty?

      value_type = attr.type
      value_type = value_type.optional_type if value_type.is_a?(Puppet::Pops::Types::POptionalType)

      value = case value_type
      when Puppet::Pops::Types::PObjectType
        xml_to_pcore(value_type, node_set)
      when Puppet::Pops::Types::PArrayType
        node_set.map { |element| xml_to_pcore(value_type.element_type, element) }
      else
        # Coerce string into an instance of the given type
        # Set YANG Empty nodes as custom boolean type
        if attr.type.type.name == "Vanilla_ice::YangEmpty" && node_set.text == ""
          #require 'pry'; binding.pry
          value_type.create(true)
        else
          value_type.create(node_set.text)
        end
      end
      i12n_hash[name] = value unless attr.default_value?(value)
    end
    i12n_hash.empty? ? nil : p_type.from_hash(i12n_hash)
  end

  # Create XML from pcore object
  def pcore_to_xml(buffer, pcore)
    buffer.print('<%s xmlns="%s">' % [pcore.xml_mapping['_puppet_property'], pcore.xmlns])
    # Process items inside pcore object
    [pcore].map do |k, v|
      if k._pcore_type.instance_of? Puppet::Pops::Types::PObjectType
        k.instance_variables.each do | i |
          node_name = i.to_s.tr('@','').tr('_','-')
          # Look for XML node mapping
          if k.respond_to? :xml_mapping
            node_name = k.xml_mapping[node_name] ? k.xml_mapping[node_name] : node_name
          end
          # If value is nested array recursively process each
          if k.instance_variable_get(i).instance_of? Array
            k.instance_variable_get(i).each do | i |
              pcore_to_xml(buffer, i)
            end
          # If value is pcore object recursively process
          elsif k.instance_variable_get(i).respond_to? :_pcore_type
            pcore_to_xml(buffer, k.instance_variable_get(i))
          # Otherwise value is a leaf
          else
            # ignore internal hash attributes added to the pcore object
            if i.to_s.tr('@','') != "hash"
              # Look for Empty YANG type and set node accordingly
              if k._pcore_type[i.to_s.tr('@','')].type.type.name == "Vanilla_ice::YangEmpty"
                if k.instance_variable_get(i)
                  buffer.print('<%s xmlns="%s" puppet="puppet"/>' % [node_name, k.xmlns])
                end
              else
                buffer.print('<%s xmlns="%s">%s</%s>' % [node_name, k.xmlns, k.instance_variable_get(i), node_name])
              end
            end
          end
        end
      end
    buffer.print("</%s>" % pcore.xml_mapping['_puppet_property'])
    end.join
  end

  # remove empty un-needed(empty) elements from xml
  def clean_xml_of_empty_elements(node)
    node.children.each do |child|
      clean_xml_of_empty_elements(child)
      if child.content.gsub(/\s+/, '').empty?
        # We have cheated and marked intentional empty nodes
        if child.attributes['puppet']
          child.remove_attribute('puppet')
        else
        child.remove
        end
      end
    end
  end
end
