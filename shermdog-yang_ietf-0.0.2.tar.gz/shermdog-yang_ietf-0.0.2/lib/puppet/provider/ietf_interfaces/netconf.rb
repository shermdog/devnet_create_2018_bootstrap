require_relative('../yang_ietf')

# rubocop:disable Style/AsciiComments
# autogen command
# pyang -f allpuppet ietf-interfaces@2014-05-08.yang ietf-ip@2014-06-16.yang iana-if-type.yang --allpuppet-output-format flush --module-name yang_ietf --pcore-name interfaces  --pcore-path ./types/
# rubocop:enable Style/AsciiComments

Puppet::Type.type(:ietf_interfaces).provide(:rest, :parent => Puppet::Provider::Yang_ietf) do
  confine :feature => :posix
  defaultfor :feature => :posix

  mk_resource_methods

  def self.instances
    path = '<interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">'
    output = Puppet::Provider::Yang_ietf.netconf_get_config(path)
    return [] if output.nil?
    instance_type = Puppet::Pops::Types::TypeParser.singleton.parse("Yang_ietf::Interfaces::Interface")
    output.xpath('//interfaces/interface').map do | variable |
      instance = xml_to_pcore(instance_type, variable)
      new(:interface => instance, :name => instance.name, :ensure => :present)
    end
  end

  def flush
    xml_template = <<-EOS
  <interfaces xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type" xmlns:if="urn:ietf:params:xml:ns:yang:ietf-interfaces" xmlns:inet="urn:ietf:params:xml:ns:yang:ietf-inet-types" xmlns:ip="urn:ietf:params:xml:ns:yang:ietf-ip" xmlns:yang="urn:ietf:params:xml:ns:yang:ietf-yang-types" xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">
    <interface xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">
      <name xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"/>
      <description xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"/>
      <type xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"/>
      <enabled xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces">True</enabled>
      <link-up-down-trap-enable xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"/>
      <ipv4 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
        <enabled xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">True</enabled>
        <forwarding xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">False</forwarding>
        <mtu xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
        <address xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
          <ip xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
          <prefix-length xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
          <netmask xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
        </address>
        <neighbor xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
          <ip xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
          <link-layer-address xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
        </neighbor>
      </ipv4>
      <ipv6 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
        <enabled xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">True</enabled>
        <forwarding xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">False</forwarding>
        <mtu xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
        <address xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
          <ip xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
          <prefix-length xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
        </address>
        <neighbor xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
          <ip xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
          <link-layer-address xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"/>
        </neighbor>
        <dup-addr-detect-transmits xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">1</dup-addr-detect-transmits>
        <autoconf xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">
          <create-global-addresses xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">True</create-global-addresses>
          <create-temporary-addresses xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">False</create-temporary-addresses>
          <temporary-valid-lifetime xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">604800</temporary-valid-lifetime>
          <temporary-preferred-lifetime xmlns="urn:ietf:params:xml:ns:yang:ietf-ip">86400</temporary-preferred-lifetime>
        </autoconf>
      </ipv6>
    </interface>
  </interfaces>
    EOS
    puppet_to_xpath_mapping = {"name" => "if:interfaces/if:interface/if:name", "interface" => "if:interfaces/if:interface"}
    namespace_hash =
    { 'ip' => 'urn:ietf:params:xml:ns:yang:ietf-ip', 'ianaift' => 'urn:ietf:params:xml:ns:yang:iana-if-type', 'yang' => 'urn:ietf:params:xml:ns:yang:ietf-yang-types', 'inet' => 'urn:ietf:params:xml:ns:yang:ietf-inet-types', 'if' => 'urn:ietf:params:xml:ns:yang:ietf-interfaces' }

    xml = Nokogiri::XML xml_template
    puppet_to_xpath_mapping.each do |puppet_name, xpath_value|
      if xml.xpath(xpath_value, namespace_hash).first
        # Check if property is set to false, if so remove from XML
        if !@property_hash[puppet_name.to_sym]
          xml.xpath(xpath_value, namespace_hash).remove
        else
          # Check if array *note currently only supports pcore values
          if @property_hash[puppet_name.to_sym].class == Array
            buffer = StringIO.new
            @property_hash[puppet_name.to_sym].each do | pcore |
              if pcore.respond_to? :_pcore_type
                pcore_to_xml(buffer, pcore)
              end
            xml.xpath(xpath_value, namespace_hash).first.replace(buffer.string)
            end
          # Check if pcore object
          elsif @property_hash[puppet_name.to_sym].respond_to? :_pcore_type
            buffer = StringIO.new
            pcore_to_xml(buffer, @property_hash[puppet_name.to_sym])
            xml.xpath(xpath_value, namespace_hash).first.replace(buffer.string)
          else
            # this is a simple attribute
            xml.xpath(xpath_value, namespace_hash).first.content = @property_hash[puppet_name.to_sym]
          end
        end
      end
    end
    if @property_hash[:ensure] == :absent
      # remove resource
      clean_xml_of_empty_elements(xml)
      xml.at_css('interface').set_attribute('operation','delete')
      Puppet::Provider::Yang_ietf.netconf_edit_config(xml)
    else
      if @original_values.empty?
        # new resource, we cannot set ipv4 / ipv6 on creation, this creates a simple interface then
        # edits the interface will all ipv4 and ipv6 information
        new_xml = xml.dup
        new_xml.at_css('name').content = name
        new_xml.xpath('if:interfaces/if:interface/ip:ipv4', namespace_hash).remove
        new_xml.xpath('if:interfaces/if:interface/ip:ipv6', namespace_hash).remove
        clean_xml_of_empty_elements(new_xml)
        Puppet::Provider::Yang_ietf.netconf_edit_config(new_xml)
      end
      # this removes all empty xml tags
      clean_xml_of_empty_elements(xml)
      result = Puppet::Provider::Yang_ietf.netconf_edit_config(xml)
    end
  end

  def create
    @create_elements = true
    @property_hash = resource.to_hash
  end

  def destroy
    @property_hash[:ensure] = :absent
  end
end
