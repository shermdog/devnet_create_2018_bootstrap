require 'spec_helper_acceptance'

describe 'should change an interface' do
  it 'change the values of said interface' do
    pp = <<-EOS
ietf_interfaces { 'GigabitEthernet4':
  interface => Yang_ietf::Interfaces::Interface({
  name => 'GigabitEthernet4',
  description => 'chicken',
  type => 'ianaift:ethernetCsmacd',
  enabled => true,
  ipv4 => Yang_ietf::Interfaces::Interface::Ipv4({
    address => [
      Yang_ietf::Interfaces::Interface::Ipv4::Address({
        ip => '192.168.251.2',
        netmask => '255.255.255.0'
      })
    ]
  }),
  ipv6 => Yang_ietf::Interfaces::Interface::Ipv6({
    address => [
      Yang_ietf::Interfaces::Interface::Ipv6::Address({
        ip => 'fd9d:77b8:d66d::',
        prefix_length => 48
      })
    ]
  })
}),
}
EOS
    make_site_pp(pp)
    run_device(options={:allow_changes => true})
    # Are we idempotent
    run_device(options={:allow_changes => false})
    # Check puppet resource
    result = run_resource('ietf_interfaces', 'GigabitEthernet4')
    expect(result).to match(/description.* => 'chicken',/)
    expect(result).to match(/enabled.* => true,/)

    # lets mix it up
    pp = <<-EOS
ietf_interfaces { 'GigabitEthernet4':
  interface => Yang_ietf::Interfaces::Interface({
  name => 'GigabitEthernet4',
  description => 'beef',
  type => 'ianaift:ethernetCsmacd',
  enabled => true,
  ipv4 => Yang_ietf::Interfaces::Interface::Ipv4({
    address => [
      Yang_ietf::Interfaces::Interface::Ipv4::Address({
        ip => '192.168.251.2',
        netmask => '255.255.255.0'
      })
    ]
  }),
  ipv6 => Yang_ietf::Interfaces::Interface::Ipv6({
    address => [
      Yang_ietf::Interfaces::Interface::Ipv6::Address({
        ip => 'fd9d:77b8:d66d::',
        prefix_length => 48
      })
    ]
  })
}),
}
EOS
    make_site_pp(pp)
    run_device(options={:allow_changes => true})
    # Are we idempotent
    run_device(options={:allow_changes => false})

    # Check puppet resource
    result = run_resource('ietf_interfaces', 'GigabitEthernet4')
    expect(result).to match(/description.* => 'beef',/)
    expect(result).to match(/enabled.* => true,/)
  end
end

describe 'should create/delete an interface' do
  it 'create an interface' do
    pp = <<-EOS
ietf_interfaces { 'Loopback69':
  ensure    => 'present',
  interface => Yang_ietf::Interfaces::Interface({
  name => 'Loopback69',
  type => 'ianaift:softwareLoopback',
  enabled => true,
  ipv4 => Yang_ietf::Interfaces::Interface::Ipv4({
    address => [
      Yang_ietf::Interfaces::Interface::Ipv4::Address({
        ip => '5.5.5.5',
        netmask => '255.255.255.0'
      })
    ]
  })
}),
}
EOS
    make_site_pp(pp)
    run_device(options={:allow_changes => true})
    # Check puppet resource
    result = run_resource('ietf_interfaces', 'Loopback69')
    expect(result).to match(/ensure.* => 'present'/)
    expect(result).to match(/enabled.* => true/)
    expect(result).to match(/ip.* => '5.5.5.5'/)
    expect(result).to match(/netmask.* => '255.255.255.0'/)
    expect(result).to match(/type.* => 'ianaift:softwareLoopback'/)
  end
  it 'delete an interface' do
    pp = <<-EOS
ietf_interfaces { 'Loopback69':
  ensure    => 'absent',
  interface => Yang_ietf::Interfaces::Interface({
  name => 'Loopback69',
  type => 'ianaift:softwareLoopback',
  enabled => true,
  ipv4 => Yang_ietf::Interfaces::Interface::Ipv4({
    address => [
      Yang_ietf::Interfaces::Interface::Ipv4::Address({
        ip => '5.5.5.5',
        netmask => '255.255.255.0'
      })
    ]
  })
}),
}
EOS
    make_site_pp(pp)
    run_device(options={:allow_changes => true})
    # Check puppet resource
    result = run_resource('ietf_interfaces', 'Loopback69')
    expect(result).to match(/ensure => 'absent',/)
  end
end
