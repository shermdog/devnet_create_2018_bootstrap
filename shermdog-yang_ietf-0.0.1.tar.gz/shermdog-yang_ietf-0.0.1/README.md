# yang_ietf

#### Table of Contents

1. [Module Description - What does the module do?](#module-description)
2. [Setup - The basics of getting started with postgresql module](#setup)
    * [What the module affects](#what-the-module-affects)
    * [Using puppet device](#using-puppet-device)
    * [Getting started](#getting-started)
3. [Usage - Configuration options and additional functionality](#usage)
    * [Configure an interface](#configure-an-interface)
4. [Reference - An under-the-hood peek at what the module is doing and how](#reference)
    * [Notes](#notes)
    * [Deviations](#deviations)
    * [Types](#types)
5. [Limitations - OS compatibility, etc.](#limitations)
6. [Development - Guide for contributing to the module](#development)
7. [Tests](#tests)

## Module description

The yang_opencondig module allows you to manage devices that comply to the ietf network standard. 

It communicates to the target device via netconf, and uses the ietf yang models as a basis for the types and providers.

## Setup

### What the module affects

* Interfaces on the device

### Using puppet device

Before you can use the module, you must create a proxy system able to run `puppet device`. Your Puppet agent will serve as the "proxy system" for the `puppet device` subcommand.

Create a device.conf file in the Puppet conf directory (/etc/puppetlabs/puppet) on the Puppet agent. Within your device.conf, you must have:

~~~
[<HOSTNAME OF DEVICE>]
type yang_ietf
url ssh://<USER>:<PASSWORD>@<HOSTNAME OF DEVICE>
~~~

In the above example, `<USERNAME>` and `<PASSWORD>` refer to Puppet's login for the device.

Additionally, you must install the net-netconf gem into the Puppet Ruby environment on the proxy host (Puppet agent). If you do not install the net-netconf gem, the module will not work.

## Reference

### Notes

All this is based on the IETF yang models. https://github.com/ietf/public/tree/master/release/models

### Deviations

Some devices to not adhere fully to standards or build more functionality on top. They are documented for each Type

### Types

* [ietf_interfaces](#ietf_interfaces): Manages the interfaces on a device.

### Type: ietf_interfaces

Manage an interface on the device.

## Limitations

Puppet Enterprise: v5.0 or greater.

## Development

Puppet Labs modules on the Puppet Forge are open projects, and community contributions are essential for keeping them great. We can’t access the huge number of platforms and myriad hardware, software, and deployment configurations that Puppet is intended to serve. We want to keep it as easy as possible to contribute changes so that our modules work in your environment. There are a few guidelines that we need contributors to follow so that we can have a chance of keeping on top of things. For more information, see our [module contribution guide](https://docs.puppetlabs.com/forge/contributing.html).

### Pyang

The allpuppet plugin generates the type / provider code. The calls used to generate the types/providers are documented at the top of each source file.

## Tests

There is one type of test distributed with this module using `rspec-system`.

To run the system tests, make sure you also have:

* A target network device
* A puppet master > 5.0.0

Edit the vmpooler nodeset.

Then run the tests using: 

```shell
PUPPET_INSTALL_TYPE=pe BEAKER_set=vmpooler bundle exec rspec spec/acceptance
```

you will be prompted to set some environment variables, for the target network device.
