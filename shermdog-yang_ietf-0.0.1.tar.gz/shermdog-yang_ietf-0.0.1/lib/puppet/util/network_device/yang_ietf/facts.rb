require_relative('../yang_ietf')

class Puppet::Util::NetworkDevice::Yang_ietf::Facts
  attr_reader :transport
  def initialize(transport)
    @transport = transport
  end

  def retrieve
  facts = {}
    facts['os'] = {}
    if @transport.connection.instance_variable_get('@trans').has_capability? 'cisco'
      facts['vendor'] = 'Cisco'
      if @transport.connection.instance_variable_get('@trans').has_capability? 'xr'
        facts['osfamily'] = 'cisco-ios-xr'
        facts['os']['family'] = 'cisco-ios-xr'
        facts['operatingsystem'] = 'IOS-XR'
        facts['os']['name'] = 'IOS-XR'
        if inv = @transport.connection.get(filter: '<platform-inventory xmlns="http://cisco.com/ns/yang/Cisco-IOS-XR-plat-chas-invmgr-oper"/>')
          facts['operatingsystemrelease'] = inv.xpath('./platform-inventory/racks/rack/attributes/basic-info/software-revision').text.strip
        end
      elsif (@transport.connection.instance_variable_get('@trans').has_capability? 'ios-xe') || (@transport.connection.instance_variable_get('@trans').has_capability? 'IOS-XE')
        facts['osfamily'] = 'cisco-ios-xe'
        facts['os']['family'] = 'cisco-ios-xe'
        facts['operatingsystem'] = 'IOS-XE'
        facts['os']['name'] = 'IOS-XE'
        if inv = @transport.connection.get(filter: '<native xmlns="http://cisco.com/ns/yang/Cisco-IOS-XE-native"><version/></native>')
          facts['operatingsystemrelease'] = inv.xpath('./native/version').text.strip
        end
      elsif @transport.connection.instance_variable_get('@trans').has_capability? 'ios'
        facts['osfamily'] = 'cisco-ios-xe'
        facts['os']['family'] = 'cisco-ios-xe'
        facts['operatingsystem'] = 'IOS-XE'
        facts['os']['name'] = 'IOS-XE'
        if inv = @transport.connection.get(filter: '<native xmlns="http://cisco.com/ns/yang/ned/ios"><version/>')
          facts['operatingsystemrelease'] = inv.xpath('./native/version').text.strip
        end
      end
    end
    facts
  end
end
