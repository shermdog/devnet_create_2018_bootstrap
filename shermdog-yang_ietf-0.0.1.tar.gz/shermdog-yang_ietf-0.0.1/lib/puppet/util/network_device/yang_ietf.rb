require 'puppet/util/network_device'

module Puppet::Util::NetworkDevice::Yang_ietf
end
