require 'puppet/property/boolean'

# rubocop:disable Style/AsciiComments
# autogen command
# pyang -f allpuppet ietf-interfaces@2014-05-08.yang ietf-ip@2014-06-16.yang iana-if-type.yang --allpuppet-output-format type --module-name yang_ietf --pcore-name interfaces  --pcore-path ./types/

# rubocop:disable LineLength

Puppet::Type.newtype(:ietf_interfaces) do
  apply_to_device
  ensurable

  newparam(:name) do
    desc 'An arbitrary name of the interface'
    isnamevar
  end
  newproperty(:interface) do
    desc 'Configuration of a routing instance.'
  end 
end
