#!/opt/puppetlabs/puppet/bin/ruby

require 'json'
require 'net/netconf'
require 'puppet'
require 'puppet/util/network_device/config'
#require 'pry'

# Constants

device_conf = '/etc/puppetlabs/puppet/device.conf'

# RPC for ietf-interfaces
rpc = '''
<rpc xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
  <get-config>
    <source>
      <running/>
    </source>
    <filter type="subtree">
      <interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"/>
    </filter>
  </get-config>
</rpc>
'''
 
# Input

args = JSON.parse(STDIN.read)
#args = JSON.parse('{"target":"csr1kv-local-1", "forbidden":"ansible"}')

#noop = args['_noop'] ? '--noop' : ''
target = args['target']
forbidden = args['forbidden']


# Pass config to Puppet - this would normally be available already on an agent run
Puppet[:deviceconfig] = "#{device_conf}"

# Get devices from config
devices = Puppet::Util::NetworkDevice::Config.devices.dup

# Remove all but taget device
devices.select! { |key, value| key == target }

# Fail if target is not configured
if devices.empty?
    # I think this will translate the error message
    error = Puppet.err _("Target device / certificate '%{target}' not found in %{config}") % { target: target, config: Puppet[:deviceconfig] }
    puts({ status: 'failure', error: error.message }.to_json)
    exit(1)
end

# Get the connection information from the config
device_url = URI.parse(devices[target].url)

# Default NETCONF port is 830
if device_url.port.nil?
  device_url.port = '830'
end

# Build connection string
login = { target: device_url.host, username: device_url.user, password: device_url.password, port: device_url.port, debug: 'true' }

# Create new Netconf device
dev = Netconf::SSH.new(login)

# Connect to device
dev.open

# Execute RPC and get result
res = dev.rpc_exec(Nokogiri::XML(rpc).root)

# Close connection to device
dev.close

# Check if interface descriptions include forbidden word
if res.xpath('//data/interfaces/interface/description').to_s.include? forbidden
  error = Puppet.err _("Forbidden keyword '%{forbidden}' found in interface description on '%{target}'") % { target: target, forbidden: forbidden }
  puts({ status: 'failure', error: error.message }.to_json)
  exit(1)
end

puts({ status: 'success' }.to_json)
exit 0
