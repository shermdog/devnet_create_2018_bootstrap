#!/opt/puppetlabs/puppet/bin/ruby

require 'json'
require 'net/netconf'
require 'puppet'
require 'puppet/util/network_device/config'
require 'pry'

# Constants

device_conf = '/etc/puppetlabs/puppet/device.conf'

# RPC for show archive
checkpoint_rpc = '''
<rpc xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
 <get>
   <filter>
     <checkpoint-archives xmlns="http://cisco.com/ns/yang/Cisco-IOS-XE-checkpoint-archive-oper"/>
   </filter>
 </get>
</rpc>'''

def rollback_rpc(archive)
  <<~HEREDOC
    <rpc xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
      <rollback xmlns="http://cisco.com/yang/cisco-ia">
      <target-url>#{archive}</target-url>
      </rollback>
    </rpc>
  HEREDOC
end
# Input

args = JSON.parse(STDIN.read)
#args = JSON.parse('{"target":"csr1kv-local-1"}')

#noop = args['_noop'] ? '--noop' : ''
target = args['target']


# Pass config to Puppet - this would normally be available already on an agent run
Puppet[:deviceconfig] = "#{device_conf}"

# Get devices from config
devices = Puppet::Util::NetworkDevice::Config.devices.dup

# Remove all but taget device
devices.select! { |key, value| key == target }

# Fail if target is not configured
if devices.empty?
    # I think this will translate the error message
    error = Puppet.err _("Target device / certificate '%{target}' not found in %{config}") % { target: target, config: Puppet[:deviceconfig] }
    puts({ status: 'failure', error: error.message }.to_json)
    exit(1)
end

# Get the connection information from the config
device_url = URI.parse(devices[target].url)

# Default NETCONF port is 830
if device_url.port.nil?
  device_url.port = '830'
end

# Build connection string
login = { target: device_url.host, username: device_url.user, password: device_url.password, port: device_url.port, debug: 'true' }

# Create new Netconf device
dev = Netconf::SSH.new(login)

# Connect to device
dev.open

# Get archive information
archive_info = dev.rpc_exec(Nokogiri::XML(checkpoint_rpc).root)

# Look for current archive set
current = archive_info.xpath('//checkpoint-archives/current').text.to_i

if current > 0
  # Get name of current archive file
  archive = archive_info.xpath("//checkpoint-archives/archives/archive/name[../number=#{current}]").text
  if archive == ''
    error = Puppet.err _("No current archive on '%{target}'") % { target: target }
    puts({ status: 'failure', error: error.message }.to_json)
    exit(1)
  end
  
  # Execute Rollback
  begin
    res = dev.rpc_exec(Nokogiri::XML(rollback_rpc(archive)).root)
    # Close connection to device
    dev.close
  rescue Netconf::RpcError => e
    error = Puppet.err _("Unable to restore config on '%{target}': %{error}") % { target: target, error: e.rsp.xpath('//rpc-error/error-message').text }
    puts({ status: 'failure', error: error.message }.to_json)
    exit(1)
  end

  # Check if snapshot was successful
  if !res.xpath('//result').text.include? 'successful'
    error = Puppet.err _("Unable to perform rollback on '%{target}'") % { target: target }
    puts({ status: 'failure', error: error.message }.to_json)
    exit(1)
  end
else
  error = Puppet.err _("No current archive on '%{target}'") % { target: target }
  puts({ status: 'failure', error: error.message }.to_json)
  exit(1)
end

puts({ status: 'success' }.to_json)
exit 0
